#Autor: José Isidro Sánchez Vázquez
#Proyecto Final Juego
#A01748144
#Grupo 2

import pygame
from random import randint
#import math
#import random

# Dimensiones de la pantalla
ANCHO = 800
ALTO = 600
# Colores
BLANCO = (255, 255, 255)  # R,G,B en el rango [0,255], 0 ausencia de color, 255 toda la intensidad
VERDE_BANDERA = (27, 94, 32)    # un poco de rojo, más de verde, un poco de azul
ROJO = (255, 0, 0)      # solo rojo, nada de verde, nada de azul
AZUL = (0, 0, 255)      # nada de rojo, ni verde, solo azul
NEGRO= (0,0,0)

#Estados DE JUEGO
MENU=1
JUGANDO=2
GAMEOVER=3
FINNIVEL1=4


#Estados de movimiento
QUIETO=1
DERECHA=2
IZQUIERDA=3

# Direccion de Palkia
PalkiaX=5
PalkiaY=5

def dibujarPalkia(ventana,spritePalkia):
    #imagen,posición
    ventana.blit(spritePalkia.image,spritePalkia.rect)

def dibujarPikachu(ventana, spritePikachu):
        ventana.blit(spritePikachu.image, spritePikachu.rect)

def dibujartrueno(ventana,listatruenos):
    for bala in listatruenos:
        ventana.blit(bala.image, bala.rect)

def moverPalkia(spritePalkia):
    global PalkiaX, PalkiaY
    spritePalkia.rect.left = spritePalkia.rect.left + PalkiaX
    spritePalkia.rect.bottom = spritePalkia.rect.bottom + PalkiaY

    #print(spriteGordito.rect.left,spriteGordito.rect.top,spriteGordito.rect.bottom,spriteGordito.rect.right)

    if spritePalkia.rect.right >= 800 or spritePalkia.rect.left <= 0 :
        PalkiaX = -PalkiaX

    if spritePalkia.rect.bottom >= 450 or spritePalkia.rect.top <= 0:
        PalkiaY = -PalkiaY


def moverPikachu(spritePikachu):
    spritePikachu.rect.left=1

def movertruenos(listatruenos):
    for balas in listatruenos:
        balas.rect.bottom -=15

def dibujarMenu(ventana, imgBtnJugar,fuente2):
    ventana.blit(imgBtnJugar,(ANCHO//2-128, ALTO//4))
    texto = fuente2.render(" ", 1, NEGRO)
    ventana.blit(texto, ((ANCHO // 2 ), 450))
    texto = fuente2.render("Palkia esta causando problemas\nen el espacio\ncapturalo rapido", 1, BLANCO)
    ventana.blit(texto, (10, 400))


def ponerFinNivel1(ventana,imgFinJuego,fuente,imgNivel2,imgMenu):
    ventana.blit(imgFinJuego, (0, 0))
    texto = fuente.render("Lo lograste", 1, NEGRO)
    ventana.blit(texto, (10, 250))
    ventana.blit(imgMenu, (50, (ALTO-150)))

def verificarColision(listatruenos,spritePalkia,puntos):

    #Se visita cada elemento de la lista de mayor a menor
    for k in range(len(listatruenos)-1,-1,-1):
        bala=listatruenos[k]
        enemigo= spritePalkia
        #bala vs enemigo
        xb=bala.rect.left
        yb= bala.rect.bottom
        xe,ye,ae,alte=enemigo.rect

        if xb>=xe and xb<=xe+ae and yb>=ye and yb<=ye+alte:
            #Le pegó!!!
            puntos+=5
            listatruenos.remove(bala)
            #Termina el ciclo que recorre a los enemigos.

        return puntos

    return puntos

def verificargolpes(listatruenos,spritePalkia,golpes):

    #Se visita cada elemento de la lista de mayor a menor
    for k in range(len(listatruenos)-1,-1,-1):
        bala=listatruenos[k]
        enemigo= spritePalkia
        #bala vs enemigo
        xb=bala.rect.left
        yb= bala.rect.bottom
        xe,ye,ae,alte=enemigo.rect

        if xb>=xe and xb<=xe+ae and yb>=ye and yb<=ye+alte:
            #Le pegó!!!
            listatruenos.remove(bala)
            #Termina el ciclo que recorre a los enemigos.
            return True

def verPuntajeMasAlto(puntos,archivo):
    entrada = open(archivo, "r")

    highScore = 0
    for linea in entrada:
        a = int(linea)
        if a <= puntos:
            highScore = puntos
        else:
            highScore = a
    entrada.close()

    salida = open(archivo, "w")
    salida.write("%s\n" % (highScore))
    salida.close()

    return highScore

def ponerGameOver(ventana,fuente,imgMenu):
    texto = fuente.render("GAME OVER", 1, ROJO)
    ventana.blit(texto, ((ANCHO // 2 - 100), 300))
    ventana.blit(imgMenu, (100, 100))

# Estructura básica de un programa que usa pygame para dibujar
def dibujar():
    # Inicializa el motor de pygame
    pygame.init()
    myfont = pygame.font.SysFont("monospace", 25)

    # Crea una ventana de ANCHO x ALTO
    ventana = pygame.display.set_mode((ANCHO, ALTO))  # Crea la ventana donde dibujará
    reloj = pygame.time.Clock()  # Para limitar los fps
    termina = False  # Bandera para saber si termina la ejecución, iniciamos suponiendo que no

    #Personaje
    Palkia=pygame.image.load("palkia.png")
    spritePalkia=pygame.sprite.Sprite()
    spritePalkia.image=Palkia
    spritePalkia.rect=Palkia.get_rect()
    spritePalkia.rect.left=randint(0,ANCHO-150)
    spritePalkia.rect.bottom= randint(125,ALTO-450)


    #Enemigo
    Pikachu=pygame.image.load("pikachu.gif")
    spritePikachu=pygame.sprite.Sprite()
    spritePikachu.image=Pikachu
    spritePikachu.rect=Pikachu.get_rect()
    spritePikachu.rect.left=0
    spritePikachu.rect.bottom= ANCHO//2 + spritePikachu.rect.width*2

    #Balas Zanahorias
    listatruenos=[]
    imgBala= pygame.image.load("Electric.png")

    #Menú
    imgFondo1=pygame.image.load("liga_Pokemon (1).png")
    imgBtnJugar=pygame.image.load("button_jugar-xd.png")
    imgNivel2=pygame.image.load("button_menu.png")
    imgMenu=pygame.image.load("button_menu.png")

    #Fondo
    imgFondo=pygame.image.load("espacio.jpg")

    #Fondo Fin del juego
    imgFinJuego=pygame.image.load("captura.jpg")

    estado=MENU
    shoots=0
    numAtack=20
    timer=0

    #velocidad=0

    # Texto
    fuente = pygame.font.SysFont("monospace", 64)
    fuente2=pygame.font.SysFont("monospace", 30)

    xFONDO=0

    puntos=0
    golpes=0

    musicaFondo = pygame.mixer.music.load("pokemon-atrapalos-ya-opening-1-full-latino-letra.mp3")
    efecto = pygame.mixer.Sound("Pikaaaa.wav")


    while not termina:  # Ciclo principal, MIENTRAS la variable termina sea False, el ciclo se repite automáticamente
        # Procesa los eventos que recibe
        for evento in pygame.event.get():
            if evento.type == pygame.QUIT:  # El usuario hizo click en el botón de salir
                termina = True      # Queremos terminar el ciclo
            #oprimir tecla, tipo de evento
            elif evento.type==pygame.KEYDOWN:
                #se pregunta ya la tecla
                if evento.key==pygame.K_LEFT:
                    spritePikachu.rect.left -= 25

                elif evento.key==pygame.K_RIGHT:
                    spritePikachu.rect.left += 25

                elif evento.key==pygame.K_UP:
                    spritePikachu.rect.bottom -= 25

                elif evento.key==pygame.K_DOWN:
                    spritePikachu.rect.bottom += 25

                elif evento.key== pygame.K_SPACE:
                    #Crear una bala
                    spritetrueno= pygame.sprite.Sprite()
                    spritetrueno.image=imgBala
                    spritetrueno.rect=imgBala.get_rect()
                    pygame.mixer.Sound.play(efecto)
                    #x de baja      coordenada personaje+ alto del personaje
                    spritetrueno.rect.left=spritePikachu.rect.left + spritePikachu.rect.width/2
                    #y de bala
                    spritetrueno.rect.bottom=spritePikachu.rect.bottom
                    listatruenos.append(spritetrueno)



        # Borrar pantalla
        #ventana.fill(NEGRO)

        if estado == JUGANDO:
            xFONDO=0


            if timer>=90:
                estado=GAMEOVER
                pygame.mixer.music.stop()
            #print(timer)

            #Actualizar enemigos
            movertruenos(listatruenos)


            moverPalkia(spritePalkia)
            puntos = verificarColision(listatruenos,spritePalkia,puntos)
            verdad=verificargolpes(listatruenos,spritePalkia,golpes)
            if verdad==True:
                golpes+=1
            if golpes>=5:
                estado=FINNIVEL1
                golpes-=5
            ventana.blit(imgFondo,(xFONDO,0))
            xFONDO-=1
            dibujarPalkia(ventana,spritePalkia)
            #moverGordito(spriteGordito)
            dibujarPikachu(ventana, spritePikachu)
            dibujartrueno(ventana,listatruenos)
            verPuntajeMasAlto(puntos,"puntaje.txt")

            tiempo = myfont.render("Time: {:02f}".format(timer), 1, (NEGRO))
            ventana.blit(tiempo, (600, 50))
            puntaje = myfont.render("puntos: {:d}".format(puntos), 1, (NEGRO))
            ventana.blit(puntaje, (600, 100))
            nivel = fuente2.render("Nivel 1", 1, NEGRO)
            ventana.blit(nivel, (20, 20))

        elif estado==MENU:
            #Dibujar MENU
            ventana.blit(imgFondo1,(0,0))
            dibujarMenu(ventana, imgBtnJugar,fuente2)
            cal=verPuntajeMasAlto(puntos,"puntaje.txt")
            puntaje = myfont.render("HIGHEST SCORE: {:d}".format(cal), 1, (NEGRO))
            ventana.blit(puntaje,(200, 300))
            #puntaje = myfont.render("Calorias: {:d}".format(cal), 1, (NEGRO))
            if evento.type==pygame.MOUSEBUTTONUP:
                #get_pos regresa una dupla, por eso se pueden poner dos variable
                xm,ym= pygame.mouse.get_pos()
                #print(xm,",",ym)
                #Preguntar si soltó el mouse dentro del boton
                xb=ANCHO//2-128
                yb=ALTO//4
                if pygame.mouse.get_pressed():
                    if xm>=xb and xm<=xb+256 and ym>=yb and ym<=yb+100:
                        estado= JUGANDO
                        pygame.mixer.music.play(1)
                        timer=0
                        puntos=0

        elif estado==FINNIVEL1:
            #ventana.blit(imgFinJuego, (0, 0))
            #xFONDO -= 0
            pygame.mixer.music.stop()
            ponerFinNivel1(ventana, imgFinJuego, fuente,imgNivel2,imgMenu)
            cal = verPuntajeMasAlto(puntos, "puntaje.txt")
            puntaje = myfont.render("HIGHEST SCORE: {:d}".format(cal), 1, (BLANCO))
            ventana.blit(puntaje, (500, 100))
            puntos = verificarColision(listatruenos, spritePalkia, puntos)
            puntajeCal = myfont.render("puntos: {:d}".format(puntos), 1, (BLANCO))
            ventana.blit(puntajeCal, (500, 150))
            if evento.type == pygame.MOUSEBUTTONUP:
                xm, ym = pygame.mouse.get_pos()
                #print(xm, ",", ym)
                # Preguntar si soltó el mouse dentro del boton
                xb = 100
                yb = ALTO // 2 -80
                xmenu=50
                ymenu=ALTO-150
                if pygame.mouse.get_pressed():
                    if xm >= xmenu and xm <= xmenu + 256 and ym >= ymenu and ym <= ymenu + 100:
                        estado = MENU
                        timer = 0
                        puntos=0




        elif estado==GAMEOVER:
            pygame.mixer.music.stop()
            ventana.fill(NEGRO)
            ponerGameOver(ventana,fuente,imgMenu)
            cal=verPuntajeMasAlto(puntos, "puntaje.txt")
            puntaje = myfont.render("HIGHEST SCORE: {:d}".format(cal), 1, (BLANCO))
            ventana.blit(puntaje, (500, 100))
            puntos = verificarColision(listatruenos, spritePalkia, puntos)
            puntajelog=myfont.render("puntaje: {:d}".format(puntos), 1, (BLANCO))
            ventana.blit(puntajelog, (500, 150))
            if evento.type == pygame.MOUSEBUTTONUP:
                pygame.event.clear()
                xm, ym = pygame.mouse.get_pos()
                #print(xm, ",", ym)
                # Preguntar si soltó el mouse dentro del boton
                xb = 100
                yb = 100
                if pygame.mouse.get_pressed():
                    if xm >= xb and xm <= xb + 256 and ym >= yb and ym <= yb + 100:
                        estado = MENU
                        timer = 0
                        puntos=0


        pygame.display.flip()  # Actualiza trazos (Si no llamas a esta función, no se dibuja)
        reloj.tick(40)  # 40 fps
        timer += 1/40


    # Después del ciclo principal
    pygame.quit()  # termina pygame


# Función principal, aquí resuelves el problema
def main():
    dibujar()   # Solo dibuja



# Llamas a la función principal
main()
