# Autor: David Yair Fernández Salas
# A01747088
# Este programa realiza el videojuego Katch it ken.
"""Se estan importando estas bibliotecas pues son necesarias para poder hacer que el juego corra"""

import pygame  # Librería de pygame
import random
from random import randint

# Dimensiones de la pantalla
ANCHO = 800
ALTO = 600
# Colores
BLANCO = (255, 255, 255)  # R,G,B en el rango [0,255], 0 ausencia de color, 255 toda la intensidad
VERDE_BANDERA = (27, 94, 32)  # un poco de rojo, más de verde, un poco de azul
ROJO = (255, 0, 0)  # solo rojo, nada de verde, nada de azul
AZUL = (0, 0, 255)  # nada de rojo, ni verde, solo azul
NEGRO = (0, 0, 0)

# Estructura básica de un programa que usa pygame para dibujar

# VARIABLES GLOBALES
xComida = ANCHO // 2
yComida = 0
DX = +10  # + hacia la derecha, - izquierda
angulo = 6


# se ponen todas las funciones que hacen que el juego corra

"""Esta función dibuja el fondo principal del juego"""
def dibujarFondo1(ventana, fondo1):
    ventana.blit(fondo1, (0, 0)) #coordenadas del fondo completo

# Dibuja el menu(botones)
"""Esta función dibuja el primer boton que sirve para que el usuario pueda dar click y empezar a jugar(por el momento
solo la dibuja"""
def dibujarbotonJugar(ventana, btnJugar, ):
    ventana.blit(btnJugar, (340, 100)) # en donde quiero dibujar las coordenadas


"""Esta función dibuja el boton de puntaje, en el fondo principal, al igual que la de arriba"""
def dibujarbotonPuntaje(ventana, btnPuntajes):
    ventana.blit(btnPuntajes, (300, 275))


"""Esta función dibuja el boton de regresar que sirve para que el usuario pueda regresar al menu principal(por el momento
 solo la dibuja)"""
def dibujarbotonRegresar(ventana,btnRegresar):
    ventana.blit(btnRegresar,(600,60))


"""Esta función dibuja el fondo dentro del juego"""
def dibujarfondo(ventana, fondoKen):
    ventana.blit(fondoKen, (0, 0))#las medidas del fondo


"""esta función dibuja a el personaje principal en la parte en la que se esta jugando """
def dibujarKen(ventana, spriteKen):
    ventana.blit(spriteKen.image, spriteKen.rect) #para que aparezca


"""Esta función dibuja la comida arroz, con los parametros de ventana, y lista comida esta última es una lista y contiene
todos los sprites de los arroces para que se puedan dibujar"""
def dibujarComidaArroz(ventana, listaComida):
    for comida in listaComida: #para que recorra cada dato de la lista
        ventana.blit(comida.image, comida.rect) #para que apraezcan


"""Esta función dibuja la comida mala (wasabi), al igual que la de arriba, usa ventana y listawasabi que contiene todos
los sprites de wasabis para que se puedan dibujar"""
def dibujarComidaMala(ventana, listaWasabi):
    for wasabi in listaWasabi:
        ventana.blit(wasabi.image, wasabi.rect) #para que aparezcan


"""esta función sirve para poder hacer mover los arroces, en la lista comida"""
def moverComidaArroz(listaComida):
    for arroz in listaComida: #lee cada dato de la lista
        arroz.rect.top += 9 #velocidad de los arroces


"""Esta función mueve la comida mala(wasabis), en la listaWasabi"""
def moverComidaMala(listaWasabi):
    for wasabi in listaWasabi: #visita cada dato en la lista
        wasabi.rect.top += 7 #velocidad


"""Esta función genera toda la comida buena(arroces)"""
def generarComidaBuena(listaComida, comidaArroz):
    spriteComidaArroz = pygame.sprite.Sprite()  # para crear enemigos a lazar
    spriteComidaArroz.image = comidaArroz
    spriteComidaArroz.rect = comidaArroz.get_rect()
    spriteComidaArroz.rect.left = random.randint(0, ANCHO - 49)
    spriteComidaArroz.rect.top = 0
    listaComida.append(spriteComidaArroz)


"""Esta función genera la comida mala (wasabis)"""
def generarComidaMala(listaWasabi, comidaWasabi):
    spriteComidaWasabi = pygame.sprite.Sprite() #para crear enemigos a lazar
    spriteComidaWasabi.image = comidaWasabi
    spriteComidaWasabi.rect = comidaWasabi.get_rect()
    spriteComidaWasabi.rect.left = random.randint(0, ANCHO - 49)
    spriteComidaWasabi.rect.top = 0
    listaWasabi.append(spriteComidaWasabi)


# Se visita cada elemento de la lista de mayor a menor
def verificarColision(listaComida, spriteKen):
    for i in range(len(listaComida) - 1, -1, -1):
        arroz = listaComida[i]
        ken = spriteKen
        xb = arroz.rect.left
        yb = arroz.rect.bottom
        # COORDENADAS DE KEN
        xKen = ANCHO // 2  # izquierda
        yKen = ALTO - 220  # arriba
        xe, ye, ae, alte = ken.rect
        if xb >= xe and xb <= xe + ae and yb >= ye and yb <= ye + alte:
            listaComida.remove(arroz)  # remueve el arroz y se acabo el ciclo for
            return True
    return False #para que se pueda cumplir el valor booleano


"""Esta función verifica si es que la comida mala toco a el personaje principal """
def verificarColisionMala(listaWasabi, spriteKen, efecto):
    for i in range(len(listaWasabi) - 1, -1, -1):
        wasabi = listaWasabi[i]
        ken = spriteKen
        xb = wasabi.rect.left
        yb = wasabi.rect.bottom
        # COORDENADAS DE KEN
        xKen = ANCHO // 2  # izquierda
        yKen = ALTO - 220  # arriba
        xe, ye, ae, alte = ken.rect
        if xb >= xe and xb <= xe + ae and yb >= ye and yb <= ye + alte:
            listaWasabi.remove(wasabi) #si lo toca se remueve el wasabi
            pygame.mixer.Sound.play(efecto) #efecto de sonido si lo toca
            return True
    return False #para que se pueda cumplir el valor booleano


"""Esta función sirve para que en la pantalla aparezca los puntos que el usario lleva registrados"""
def dibujarmarcador(ventana, fuente, puntos):
    texto = fuente.render("Puntos: " + str(puntos), 1, ROJO) #tamaño,letra,color
    ventana.blit(texto, (20, 50)) #lugar donde se va a ver


"""Esta función sirve para dibujar el fondo de cuando el usario pierde"""
def dibujarFondoPierde(ventana, fondoPierde):
    ventana.blit(fondoPierde, (0, 0)) #tamaño de el fondo


"""Esta función sirve para guardar el puntaje más alto resgitrado, usando los parametros de los puntos obtenidos, y
un archivo.txt donde se guardan los resultados"""
def guardarPuntajeMasAlto(puntos, archivo):
    entrada = open(archivo, "r") #para leer
    for linea in entrada:
        a=int(linea)
    if a<= puntos:
        a = puntos

    entrada.close()
    salida = open(archivo, "w") #para escribir
    salida.write("%s\n" % (a))
    salida.close()
    return a #regresa el valor=puntos


"""esta función dibuja el fondo de cuando el usuario pica en el botón de puntaje sale este fondo"""
def dibujarFondoPuntaje(ventana, fondoNegro):
    ventana.blit(fondoNegro, (0, 0))


def dibujar():
    # Inicializa el motor de pygame
    pygame.init()
    # Crea una ventana de ANCHO x ALTO
    ventana = pygame.display.set_mode((ANCHO, ALTO))  # Crea la ventana donde dibujará
    reloj = pygame.time.Clock()  # Para limitar los fps
    termina = False  # Bandera para saber si termina la ejecución, iniciamos suponiendo que no

    # IMAGENES QUE SE USAN EN LOS FONDOS DEL JUEGO
    fondo1 = pygame.image.load("fondo1.png")
    titulo = pygame.image.load("ken.png")
    fondoKen = pygame.image.load("fondoken.png")
    fondoPierde = pygame.image.load("gameover.jpg")
    fondoNegro = pygame.image.load("fondoNegro.jpg")

    # IMAGENES DE LOS BOTONES
    btnJugar = pygame.image.load("button_jugar.png")
    btnPuntajes = pygame.image.load("button_puntajes.png")
    btnRegresar= pygame.image.load("button_regresar.png")

    # SPRITE DE PERSONAJE PRINCIPAL
    ken = pygame.image.load("ken.png")
    spriteKen = pygame.sprite.Sprite()
    spriteKen.image = ken
    spriteKen.rect = ken.get_rect()
    spriteKen.rect.left = ANCHO // 2
    spriteKen.rect.right = ALTO - 220
    spriteKen.rect.bottom = ALTO

    # SPRITES DE LA COMIDA BUENA
    comidaArroz = pygame.image.load("comidaArroz.png")
    spriteComidaArroz = pygame.sprite.Sprite()
    spriteComidaArroz.image = comidaArroz
    spriteComidaArroz.rect = comidaArroz.get_rect()
    spriteComidaArroz.rect.left = -1
    spriteComidaArroz.rect.top = -1

    # SPRITE DE LA COMIDA BUENA 2
    comidaArroz = pygame.image.load("comidaArroz.png")
    spriteComidaArroz2 = pygame.sprite.Sprite()
    spriteComidaArroz2.image = comidaArroz
    spriteComidaArroz2.rect = comidaArroz.get_rect()
    spriteComidaArroz2.rect.left = -1
    spriteComidaArroz2.rect.top = -1

    # SPRITE DE LA COMIDA BUENA 3
    comidaArroz = pygame.image.load("comidaArroz.png")
    spriteComidaArroz3 = pygame.sprite.Sprite()
    spriteComidaArroz3.image = comidaArroz
    spriteComidaArroz3.rect = comidaArroz.get_rect()
    spriteComidaArroz3.rect.left = -1
    spriteComidaArroz3.rect.top = -1

    # SPRITES DE LA COMIDA MALA
    comidaWazabi = pygame.image.load("wasabi.png")
    spriteComidaWasabi = pygame.sprite.Sprite()
    spriteComidaWasabi.image = comidaWazabi
    spriteComidaWasabi.rect = comidaWazabi.get_rect()
    spriteComidaWasabi.rect.left = -1
    spriteComidaWasabi.rect.top = -1

    #SPRITE DE LA COMIDA MALA 2
    comidaWazabi2 = pygame.image.load("wasabi.png")
    spriteComidaWasabi2 = pygame.sprite.Sprite()
    spriteComidaWasabi2.image = comidaWazabi
    spriteComidaWasabi2.rect = comidaWazabi.get_rect()
    spriteComidaWasabi2.rect.left = -1
    spriteComidaWasabi2.rect.top = -1

    #SPRITES DE LA COMIDA MALA 3
    comidaWazabi3 = pygame.image.load("wasabi.png")
    spriteComidaWasabi3 = pygame.sprite.Sprite()
    spriteComidaWasabi3.image = comidaWazabi
    spriteComidaWasabi3.rect = comidaWazabi.get_rect()
    spriteComidaWasabi3.rect.left = -1
    spriteComidaWasabi3.rect.top = -1

    # COORDENADAS DEL CIRCULO
    xMouse = -1
    yMouse = -1

    # ESTADOS
    MENU = 1
    JUGANDO = 2
    PUNTAJE = 3
    PIERDE = 4
    estado = MENU  # al inicio muestra el menú

    # AUDIO(SONIDO)
    pygame.mixer.init()
    # sonido largo music --mp3
    pygame.mixer.music.load("la fiesta de las medusas.mpeg")
    pygame.mixer.music.play(-1)
    efecto = pygame.mixer.Sound("shoot.wav")

    # TEXTO
    fuente = pygame.font.SysFont("arial", 30)

    # Puntos
    puntos = 0  # NO ES GLOBAL
    myfont = pygame.font.SysFont("monospace", 25)

    # LISTAS
    listaComida = [spriteComidaArroz, spriteComidaArroz2, spriteComidaArroz3]
    listaWasabi = [spriteComidaWasabi, spriteComidaWasabi2, spriteComidaWasabi3]

    # CONTADORES DE TIEMPO PARA EL ARROZ
    contadortiempoArroz = 20
    # CONTADORES DE TIEMPO PARA EL WASABI
    contadortiempoWasabi = 50

    while not termina:  # Ciclo principal, MIENTRAS la variable termina sea False, el ciclo se repite automáticamente
        # Procesa los eventos que recibe
        for evento in pygame.event.get():
            if evento.type == pygame.QUIT:  # El usuario hizo click en el botón de salir
                termina = True  # Queremos terminar el ciclo
            if evento.type == pygame.MOUSEBUTTONDOWN:
                xMouse, yMouse = pygame.mouse.get_pos()
                if xMouse >= 335 and xMouse <= 475 and yMouse >= 100 and yMouse <= 150:
                    xMouse = -1
                    # CAMBIA EL ESTADO
                    estado = JUGANDO  # PASA A JUGAR
            elif evento.type == pygame.MOUSEBUTTONDOWN:
                xMouse, yMouse = pygame.mouse.get_pos()
                if xMouse >= 335 and xMouse <= 475 and yMouse >= 400 and yMouse <=450 :
                    xMouse = -1
            elif evento.type == pygame.KEYDOWN:  # tecla oprimida
                if evento.key == pygame.K_RIGHT:  # Flecha derecha??
                    spriteKen.rect.left += 50
                elif evento.key == pygame.K_LEFT:
                    spriteKen.rect.right -= 50

        # Borrar pantalla
        ventana.fill(NEGRO)
        if estado == MENU:
            dibujarFondo1(ventana, fondo1)
            dibujarbotonJugar(ventana, btnJugar)
            dibujarbotonPuntaje(ventana, btnPuntajes)

            if evento.type == pygame.MOUSEBUTTONDOWN:
                xMouse, yMouse = pygame.mouse.get_pos()
                if xMouse >= 300 and xMouse <= 440 and yMouse >= 275 and yMouse <= 325:
                    xMouse = -1
                    estado = PUNTAJE


        elif estado == JUGANDO:
            contadortiempoArroz -= 1
            if contadortiempoArroz == 0:
                generarComidaBuena(listaComida, comidaArroz)
                contadortiempoArroz = 100

            contadortiempoWasabi -= 1
            if contadortiempoWasabi == 0:
                generarComidaMala(listaWasabi, comidaWazabi)
                contadortiempoWasabi = 50
            # Dibuja todas las imagenes
            dibujarfondo(ventana, fondoKen)
            dibujarKen(ventana, spriteKen)
            dibujarComidaArroz(ventana, listaComida)
            dibujarComidaMala(ventana, listaWasabi)
            moverComidaArroz(listaComida)
            moverComidaMala(listaWasabi)
            dibujarmarcador(ventana, fuente, puntos)
            resultado = (verificarColision(listaComida, spriteKen))
            # if resultado==True:
            # pygame.mixer.Sound.play(efecto)
            morir = verificarColisionMala(listaWasabi, spriteKen, efecto) == True
            if resultado == True:
                puntos += 5
            if morir == True:
                estado = PIERDE
                guardarPuntajeMasAlto(puntos,"archivo.txt")

        elif estado == PIERDE:
            dibujarFondoPierde(ventana, fondoPierde)
            dibujarbotonRegresar(ventana,btnRegresar)
            if evento.type == pygame.MOUSEBUTTONDOWN:
                xMouse, yMouse = pygame.mouse.get_pos()
                if xMouse >= 600 and xMouse <= 723 and yMouse >= 60 and yMouse <= 100:
                    xMouse = -1
                    estado= MENU
                    puntos=0

        elif estado == PUNTAJE:
            dibujarFondoPuntaje(ventana, fondoNegro)
            punto = guardarPuntajeMasAlto(puntos, "archivo.txt")
            puntaje = myfont.render("PUNTAJE MAS ALTO: {:d}".format(punto), 1, (BLANCO))
            ventana.blit(puntaje, (300, 300))
            dibujarbotonRegresar(ventana, btnRegresar)
            if evento.type == pygame.MOUSEBUTTONDOWN:
                xMouse, yMouse = pygame.mouse.get_pos()
                if xMouse >= 600 and xMouse <= 723 and yMouse >= 60 and yMouse <= 100:
                    xMouse = -1
                    estado = MENU
                    puntos = 0

        pygame.display.flip()  # Actualiza trazos (Si no llamas a esta función, no se dibuja)
        reloj.tick(40)  # 40 fps

    # Después del ciclo principal
    pygame.quit()  # termina pygame


# Función principal, aquí resuelves el problema
def main():
    dibujar()  # Por ahora, solo dibuja


# Llamas a la función principal
main()