# Victor Manuel Cerón Navarrete
# Proyecto final de fundamentos de programación

import pygame # Librería de pygame
import random

# Dimensiones de la pantalla
ANCHO = 800
ALTO = 600

# Colores
BLANCO = (255, 255, 255)
NEGRO = (0, 0, 0)

"""
CONFIGURACIÓN INICIAL
"""

# Sonido
pygame.mixer.init(22050, 8, 2, 4096)
GAME_VOLUME = .1

# Texto
pygame.font.init()
myfont = pygame.font.Font('Material/102.ttf', 80)

# Archivo con el RECORD
recordtxt = open("RECORD.txt", "r+")
RECORD = float(recordtxt.readlines()[len(recordtxt.readlines()) - 1])

# Variables globales
PUNTOS = 0
ESTADO = 0
LASTIMADO = 0

# ESTADOS DEL JUEGO
MENU = 0
JUEGO = 1
PUNTUACIONES = 2

# Importar Imágenes
imgJugador = pygame.image.load("Material/vivo.png")
imgJugador2 = pygame.image.load("Material/lastimado.png")
imgJugador3 = pygame.image.load("Material/muerto.png")
imgSacerdote = pygame.image.load("Material/malo.png")
imgCruz = pygame.image.load("Material/cruzbala.png")
imgFondo = pygame.image.load("Material/fondo.png")
imgInicio = pygame.image.load("Material/inicio.png")
imgCorazonBien = pygame.image.load("Material/corazonbien.png")
imgCorazonMal = pygame.image.load("Material/corazonmal.png")

# Crear personajes
Jugador = pygame.sprite.Sprite()
Jugador.image = imgJugador
Jugador.rect = Jugador.image.get_rect()
Jugador.rect.top = 500
Jugador.rect.left = 300

Sacerdote = pygame.sprite.Sprite()
Sacerdote.image = imgSacerdote
Sacerdote.rect = Sacerdote.image.get_rect()
Sacerdote.rect.top = 20
Sacerdote.rect.left = 300

# Variables personajes
VIDAS_JUGADOR = 3
SACERDOTE_SENTIDO = 1

# Crear lista para las cruces
Cruz = []

# Sonidos
cancionInicio = pygame.mixer.Sound('Material/musicaInicio.wav')
cancionJugando = pygame.mixer.Sound('Material/musicaJugando.wav')
cancionMuerte = pygame.mixer.Sound('Material/musicaMuerte.wav')
sonidoDisparo = pygame.mixer.Sound('Material/sonidoDisparo.wav')

# Variables de dificultad
velocidadJugador = 20
velocidadSacerdote = 30
velocidadCruz = 15


def CrearCruz():
    newCruz = pygame.sprite.Sprite()
    newCruz.image = imgCruz
    newCruz.rect = newCruz.image.get_rect()
    newCruz.rect.left = Sacerdote.rect.left
    newCruz.rect.top = 55
    Cruz.append(newCruz)


def mainJuego():
    global SACERDOTE_SENTIDO, PUNTOS, VIDAS_JUGADOR, ESTADO, RECORD
    if Sacerdote.rect.right > ANCHO or Sacerdote.rect.left < 5:
        SACERDOTE_SENTIDO *= -1
    if random.randint(0, 10) == 0:
        CrearCruz()
        pygame.mixer.Sound.play(sonidoDisparo, 0)
        pygame.mixer.Sound.set_volume(sonidoDisparo, GAME_VOLUME/2)
    for cruz in Cruz:
        cruz.rect.top += velocidadCruz
        if pygame.sprite.collide_rect(Jugador, cruz):
            VIDAS_JUGADOR -= 1
            LASTIMADO = 20
            if VIDAS_JUGADOR == 0:
                ESTADO = PUNTUACIONES
                if PUNTOS > RECORD:
                    RECORD = PUNTOS
                    recordtxt.write(str(PUNTOS) + '\n')
                Cruz.clear()
                pygame.mixer.stop()
                pygame.mixer.Sound.play(cancionMuerte, 0)
                pygame.mixer.Sound.set_volume(cancionMuerte, GAME_VOLUME)
                break
            Cruz.remove(cruz)
            break
        if cruz.rect.top > 620:
            Cruz.remove(cruz)
            PUNTOS += 20
    Sacerdote.rect.left += SACERDOTE_SENTIDO * velocidadSacerdote


def dibujar(ventana):
    if ESTADO == MENU:
        ventana.fill(NEGRO)
        ventana.blit(imgInicio, (198, 175))
        text = myfont.render('Jugar', True, BLANCO)
        text2 = myfont.render('Instrucciones', True, BLANCO)
        text3 = myfont.render('Evita las cruces', True, BLANCO)
        ventana.blit(text, (320, 60))
        ventana.blit(text2, (200, 450))
        ventana.blit(text3, (160, 520))

    if ESTADO == JUEGO:
        mainJuego()

        ventana.blit(imgFondo, (0, 0))
        ventana.blit(Sacerdote.image, Sacerdote.rect)

        if LASTIMADO> 0:
            Jugador.image = imgJugador2
        else:
            Jugador.image = imgJugador
        ventana.blit(Jugador.image, Jugador.rect)

        if VIDAS_JUGADOR == 3:
            ventana.blit(imgCorazonBien, (600, 500))
            ventana.blit(imgCorazonBien, (670, 500))
            ventana.blit(imgCorazonBien, (740, 500))
        if VIDAS_JUGADOR == 2:
            ventana.blit(imgCorazonMal, (600, 500))
            ventana.blit(imgCorazonBien, (670, 500))
            ventana.blit(imgCorazonBien, (740, 500))
        if VIDAS_JUGADOR == 1:
            ventana.blit(imgCorazonMal, (600, 500))
            ventana.blit(imgCorazonMal, (670, 500))
            ventana.blit(imgCorazonBien, (740, 500))
        for cruz in Cruz:
            ventana.blit(cruz.image, cruz.rect)
        text = myfont.render('PUNTOS:' + str(PUNTOS), True, NEGRO)
        ventana.blit(text, (20, 20))

    if ESTADO == PUNTUACIONES:
        ventana.fill(NEGRO)
        text = myfont.render('Highscore: ' + str(int(RECORD)), True, BLANCO)
        text2 = myfont.render('Puntuacion: ' + str(PUNTOS), True, BLANCO)
        ventana.blit(imgJugador3, (Jugador.rect.left, 500))
        ventana.blit(text, (150, 200))
        ventana.blit(text2, (150, 400))
    
    pygame.display.flip() # Actualiza la pantalla

# Inicia canción del menú con volumen escogido
pygame.mixer.Sound.play(cancionInicio)
pygame.mixer.Sound.set_volume(cancionInicio, GAME_VOLUME)

# Loop principal
def main():
    global ESTADO, LASTIMADO, VIDAS_JUGADOR
    # Inicializa el motor de pygame
    pygame.init()

    # Crea una ventana de ANCHO x ALTO
    ventana = pygame.display.set_mode((ANCHO, ALTO)) # Crea la ventana donde dibujará
    reloj = pygame.time.Clock()  # Para limitar los fps
    termina = False # Bandera para saber si termina la ejecución, iniciamos suponiendo que no

    while not termina:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                termina = True

            if event.type == pygame.MOUSEBUTTONUP:
                if ESTADO == MENU:
                    pos = pygame.mouse.get_pos()
                    if 300 < pos[0] < 600 and 60 < pos[1] < 200:
                        ESTADO = 1
                        pygame.mixer.stop()
                        pygame.mixer.Sound.play(cancionJugando, 0)
                        pygame.mixer.Sound.set_volume(cancionJugando, GAME_VOLUME)
                if ESTADO == PUNTUACIONES:
                    ESTADO = MENU
                    PUNTOS = 0
                    VIDAS_JUGADOR = 3
                    LASTIMADO = 0
                    pygame.mixer.stop()
                    pygame.mixer.Sound.play(cancionInicio, 0)
                    pygame.mixer.Sound.set_volume(cancionInicio, GAME_VOLUME)

        keys = pygame.key.get_pressed()

        if keys[pygame.K_ESCAPE]:
            run = False

        if ESTADO == JUEGO:
            LASTIMADO -= 1
            
            if keys[pygame.K_LEFT]:
                if Jugador.rect.left - 5 > 0:
                    Jugador.rect.left -= velocidadJugador

            if keys[pygame.K_RIGHT]:
                if Jugador.rect.left + 100 < 800:
                    Jugador.rect.left += velocidadJugador

            if keys[pygame.K_UP]:
                if Jugador.rect.top > 400:
                    Jugador.rect.top -= velocidadJugador

            if keys[pygame.K_DOWN]:
                if Jugador.rect.bottom < 600:
                    Jugador.rect.bottom += velocidadJugador

        dibujar(ventana)
        reloj.tick(30)

main()

recordtxt.close()
pygame.mixer.quit()
pygame.quit()
