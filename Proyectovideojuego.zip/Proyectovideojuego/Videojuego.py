# encoding: UTF-8
# Autor: Alan Giovanni Rodriguez Camacho
# Videojuego cuyo objetivo es obtener puntos eliminando enemigos y esquivarlos para no perder vida.

import pygame   # Librería de pygame

# Dimensiones de la pantalla
ANCHO = 800
ALTO = 600
# Colores
BLANCO = (255, 255, 255)  # R,G,B en el rango [0,255], 0 ausencia de color, 255 toda la intensidad
VERDE_BANDERA = (27, 94, 32)    # un poco de rojo, más de verde, un poco de azul
ROJO = (255, 0, 0)      # solo rojo, nada de verde, nada de azul
AZUL = (0, 0, 255)      # nada de rojo, ni verde, solo azul
NEGRO = (0,0,0)


# Estructura básica de un programa que usa pygame para dibujar
def dibujarFondo(ventana,fondoJuego):
    ventana.blit(fondoJuego, (0,0))


def dibujarMenu(ventana, btnStart):
    ventana.blit(btnStart, (300,275))


def dibujarFondoMenu(ventana, fondoMenu):
    ventana.blit(fondoMenu, (0,0))


def dibujarTitulo(ventana, tituloMenu):
    ventana.blit(tituloMenu, (160,100))


def dibujarMenuSalida(ventana, btnExit):
    ventana.blit(btnExit, (305,400))


def dibujarYeti(ventana, spriteYeti):
    ventana.blit(spriteYeti.image, spriteYeti.rect)


def crearBala(imgBala, listaBalas, spriteYeti):
    spriteBala = pygame.sprite.Sprite()
    spriteBala.image = imgBala
    spriteBala.rect = imgBala.get_rect()
    spriteBala.rect.left = spriteYeti.rect.left + 50 - 16
    spriteBala.rect.top = spriteYeti.rect.top + 80
    listaBalas.append(spriteBala)


def barraVida(vida,spriteYeti,ventana):
    pygame.draw.rect(ventana, (0, 255, 0),(spriteYeti.rect.left, spriteYeti.rect.top - 20, 100, 10))


def dibujarListaBalas(ventana, listaBalas):
    for bala in listaBalas:
        ventana.blit(bala.image, bala.rect)


def moverBalas(listaBalas):
    for bala in listaBalas:
        bala.rect.right += 25
        if bala.rect.right > + 805:
            listaBalas.remove(bala)


def dibujarTecho(ventana, imgTecho):
    ventana.blit(imgTecho,(0,-30))


def dibujarMarcador(ventana, font, score):
    texto = font.render("Score: " + str(score), 1, BLANCO)
    ventana.blit(texto,(630,560))

def dibujarListaEnemigos1(ventana, listaEnemigos1):
    for enemigo in listaEnemigos1:
        ventana.blit(enemigo.image, enemigo.rect)


def dibujarListaEnemigos2(ventana, listaEnemigos2):
    for enemigo in listaEnemigos2:
        ventana.blit(enemigo.image, enemigo.rect)


def dibujarListaEnemigos3(ventana, listaEnemigos3):
    for enemigo in listaEnemigos3:
        ventana.blit(enemigo.image, enemigo.rect)


def generarCazadores(listaEnemigos1, imgEnemigo1):
    for x in range(800, 50000, 500):
        spriteEnemigo = pygame.sprite.Sprite()
        spriteEnemigo.image = imgEnemigo1
        spriteEnemigo.rect = imgEnemigo1.get_rect()
        spriteEnemigo.rect.left = x
        spriteEnemigo.rect.top = 380
        listaEnemigos1.append(spriteEnemigo)


def generarArqueros(listaEnemigos2, imgEnemigo2):
    for x in range(1000, 50000, 1000):
        spriteEnemigo = pygame.sprite.Sprite()
        spriteEnemigo.image = imgEnemigo2
        spriteEnemigo.rect = imgEnemigo2.get_rect()
        spriteEnemigo.rect.left = x
        spriteEnemigo.rect.top = 340
        listaEnemigos2.append(spriteEnemigo)


def generarHelicopteros(listaEnemigos3, imgEnemigo3):
    for x in range(2000, 50000, 1500):
        spriteEnemigo = pygame.sprite.Sprite()
        spriteEnemigo.image = imgEnemigo3
        spriteEnemigo.rect = imgEnemigo3.get_rect()
        spriteEnemigo.rect.left = x
        spriteEnemigo.rect.top = 210
        listaEnemigos3.append(spriteEnemigo)


def moverArqueros(listaEnemigos2):
    for enemigo in listaEnemigos2:
        enemigo.rect.left -=40
        if enemigo.rect.left < 0:
            listaEnemigos2.remove(enemigo)


def moverEnemigos(listaEnemigos1):
    for enemigo in listaEnemigos1:
        enemigo.rect.left -=25
        if enemigo.rect.left < 0:
            listaEnemigos1.remove(enemigo)


def moverHelicopteros(listaEnemigos3):
    for enemigo in listaEnemigos3:
        enemigo.rect.left -=70
        if enemigo.rect.left < 0:
            listaEnemigos3.remove(enemigo)


def verificarColisionesListaEnemigos1(listaBalas, listaEnemigos1):
    for enemigos in listaEnemigos1:
        for bala in listaBalas:
            if bala.rect.colliderect(enemigos) == True:       #prueba colisión directamente
                listaEnemigos1.remove(enemigos)
                listaBalas.remove(bala)


def verificarColisionesListaEnemigos2(listaBalas, listaEnemigos2):
    for enemigos in listaEnemigos2:
        for bala in listaBalas:
            if bala.rect.colliderect(enemigos) == True:       #prueba colisión directamente
                listaEnemigos2.remove(enemigos)
                listaBalas.remove(bala)


def verificarColisionesListaEnemigos3(listaBalas, listaEnemigos3):
    for enemigos in listaEnemigos3:
        for bala in listaBalas:
            if bala.rect.colliderect(enemigos) == True:       #prueba colisión directamente
                listaEnemigos3.remove(enemigos)
                listaBalas.remove(bala)


def dibujarPause(ventana, btnMenu):
    ventana.blit(btnMenu, (700,0))


def verificarColisionYeti(ventana, spriteYeti, listaEnemigos1,herida):
    for enemigos in listaEnemigos1:
        if spriteYeti.rect.colliderect(enemigos) == True:       #prueba colisión directamente
            pygame.draw.rect(ventana, (255, 0, 0), (spriteYeti.rect.left , spriteYeti.rect.top - 20, 100, 10))
            listaEnemigos1.remove(enemigos)
            herida.play()


def verificarColisionYeti2(ventana, spriteYeti, listaEnemigos2,herida):
    for enemigos in listaEnemigos2:
        if spriteYeti.rect.colliderect(enemigos) == True:       #prueba colisión directamente
            pygame.draw.rect(ventana, (255, 0, 0), (spriteYeti.rect.left , spriteYeti.rect.top - 20, 100, 10))
            listaEnemigos2.remove(enemigos)
            herida.play()


def verificarColisionYeti3(ventana, spriteYeti, listaEnemigos3,herida):
    for enemigos in listaEnemigos3:
        if spriteYeti.rect.colliderect(enemigos) == True:       #prueba colisión directamente
            pygame.draw.rect(ventana, (255, 0, 0), (spriteYeti.rect.left, spriteYeti.rect.top - 20, 100, 10))
            listaEnemigos3.remove(enemigos)
            herida.play()


def dibujarTeclas(ventana, imgTeclas, imgSpace, howTo):
    ventana.blit(howTo, (530,350))
    ventana.blit(imgTeclas, (600,430))
    ventana.blit(imgSpace,(600, 560))

def dibujar():
    # Inicializa el motor de pygame
    pygame.init()
    # Crea una ventana de ANCHO x ALTO
    ventana = pygame.display.set_mode((ANCHO, ALTO))  # Crea la ventana donde dibujará
    reloj = pygame.time.Clock()  # Para limitar los fps
    termina = False  # Bandera para saber si termina la ejecución, iniciamos suponiendo que no

    # IMAGENES
    btnStart = pygame.image.load("btnStart.png")
    fondoJuego = pygame.image.load("FondoNieve.jpg")
    fondoMenu = pygame.image.load("FondoNieve.jpg")
    tituloMenu = pygame.image.load("YetiRun.png")
    btnExit = pygame.image.load("exitbtn.png")
    btnMenu = pygame.image.load("btnMenu.png")
    imgEnemigo1 = pygame.image.load("cazador.png")
    imgEnemigo2 = pygame.image.load("arquero.png")
    imgEnemigo3 = pygame.image.load("helicoptero.png")
    imgTecho = pygame.image.load("techo.png")
    imgTeclas = pygame.image.load("arrows.png")
    imgSpace = pygame.image.load("space.png")
    howTo = pygame.image.load("howto.png")


    xYeti = ANCHO//2-200          #IZQUIERDA
    yYeti = ALTO-200           #DERECHA

    imgYeti = pygame.image.load("realYeti.png")
    spriteYeti = pygame.sprite.Sprite()
    spriteYeti.image = imgYeti
    spriteYeti.rect = imgYeti.get_rect()

    spriteYeti.rect.top = yYeti
    spriteYeti.rect.left = xYeti


    #Balas (sprites)
    imgBala = pygame.image.load("snowball.png")
    spriteBala = pygame.sprite.Sprite()
    spriteBala.image = imgBala
    spriteBala.rect = imgBala.get_rect()
    spriteBala.rect.left = -1

    #COORDENADAS
    xMouse = -1
    yMouse = -1

    #
    isJump = False
    jumpCount = 5
    vida = 10

    # ESTADOS
    MENU = 1
    JUGANDO = 2
    ESTADO = MENU

    # AUDIO(SONIDO)
    pygame.mixer.init()
    # sonido corto  Sound -- wav
    efectoDisparo = pygame.mixer.Sound("shoot.wav")
    herida = pygame.mixer.Sound("hurt.wav")
    # Sonido largo Music --mp3
    music = pygame.mixer.music.load("Musica.mp3")
    pygame.mixer.music.play(-1)

    # TEXTO
    font = pygame.font.SysFont("comic sans ms", 30, True)

    # puntos
    score = 0


    # LISTA DE ENEMIGOS
    listaEnemigos1 = []
    listaEnemigos2 = []
    listaEnemigos3 = []
    generarCazadores(listaEnemigos1, imgEnemigo1)
    generarArqueros(listaEnemigos2, imgEnemigo2)
    generarHelicopteros(listaEnemigos3, imgEnemigo3)

    # LISTA DE BALAS
    listaBalas = []  # Lista vacia


    while not termina:  # Ciclo principal, MIENTRAS la variable termina sea False, el ciclo se repite automáticamente
        # Procesa los eventos que recibe
        for evento in pygame.event.get():
            if evento.type == pygame.QUIT:  # El usuario hizo click en el botón de salir
                termina = True      # Queremos terminar el ciclo
            elif evento.type == pygame.MOUSEBUTTONDOWN:
                xMouse, yMouse = pygame.mouse.get_pos()
                if xMouse >= 300 and xMouse <= 500 and yMouse >=275 and yMouse <=350:
                    ESTADO = JUGANDO #PASA A JUGANDO

                elif xMouse>= 700 and xMouse <= 800 and yMouse >= 0 and yMouse <=50:
                    ESTADO = MENU

            elif evento.type == pygame.KEYDOWN:  # TECLA OPRIMIDA
                if evento.key == pygame.K_SPACE:
                    if len(listaBalas) < 2:
                        crearBala(imgBala, listaBalas, spriteYeti)
                    efectoDisparo.play()
                    spriteBala.rect.left = spriteYeti.rect.left + 64 - 16  # poscisiones, Proyecto(getWidth...)
                    spriteBala.rect.top = spriteYeti.rect.top

        key = pygame.key.get_pressed()
        if key[pygame.K_RIGHT] and spriteYeti.rect.left < 680:#flecha derecha??
            spriteYeti.rect.left += 20
        if key[pygame.K_LEFT] and spriteYeti.rect.left > 20:#flecha izquierda??
            spriteYeti.rect.left -= 20
        if not(isJump):
            if key[pygame.K_UP]:
                isJump = True
        else:
            if jumpCount >= -5:
                neg = 8
                if jumpCount < 0:
                    neg = -8
                spriteYeti.rect.top -= (jumpCount**2) *0.5 * neg
                jumpCount -= 1
            else:
                isJump = False
                jumpCount = 5


        # Borrar pantalla
        ventana.fill(NEGRO)

        if ESTADO == MENU:
            dibujarFondoMenu(ventana, fondoMenu)
            dibujarMenu(ventana, btnStart)
            dibujarTitulo(ventana, tituloMenu)
            dibujarMenuSalida(ventana,btnExit)
            dibujarTeclas(ventana, imgTeclas, imgSpace, howTo)
            if evento.type == pygame.MOUSEBUTTONDOWN:
                xMouse, yMouse = pygame.mouse.get_pos()
                if xMouse >= 305 and xMouse <= 500 and yMouse >= 400 and yMouse <= 550:
                    termina = True

        elif ESTADO == JUGANDO:
            moverBalas(listaBalas)
            dibujarFondo(ventana, fondoJuego)
            dibujarYeti(ventana, spriteYeti)
            barraVida(vida, spriteYeti, ventana)
            dibujarListaBalas(ventana, listaBalas)
            dibujarTecho(ventana, imgTecho)
            dibujarPause(ventana, btnMenu)
            dibujarMarcador(ventana, font, score)
            dibujarListaEnemigos1(ventana, listaEnemigos1)
            moverEnemigos(listaEnemigos1)
            dibujarListaEnemigos2(ventana,listaEnemigos2)
            moverArqueros(listaEnemigos2)
            dibujarListaEnemigos3(ventana, listaEnemigos3)
            moverHelicopteros(listaEnemigos3)

            colision1 = verificarColisionYeti(ventana, spriteYeti, listaEnemigos1,herida)
            colision2 = verificarColisionYeti2(ventana, spriteYeti, listaEnemigos2,herida)
            colision3 = verificarColisionYeti3(ventana, spriteYeti, listaEnemigos3,herida)


            resultado1 = verificarColisionesListaEnemigos1(listaBalas, listaEnemigos1)
            resultado2 = verificarColisionesListaEnemigos2(listaBalas, listaEnemigos2)
            resultado3 = verificarColisionesListaEnemigos3(listaBalas, listaEnemigos3)
            if resultado1 == True:
                score += 1
            elif resultado1 == False:
                score == score
            if resultado2 == True:
                score += 1
            elif resultado2 == False:
                score == score
            if resultado3 == True:
                score += 1
            elif resultado3 == False:
                score == score

        pygame.display.flip()  # Actualiza trazos (Si no llamas a esta función, no se dibuja)
        reloj.tick(40)  # 40 fps

    # Después del ciclo principal
    pygame.quit()  # termina pygame


# Función principal, aquí resuelves el problema
def main():
    dibujar()   # Por ahora, solo dibuja


# Llamas a la función principal
main()