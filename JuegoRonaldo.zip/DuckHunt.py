
# Autor: Ronaldo Estefano Lira
# Proyecto final, juego duck hunt

import pygame   # Librería de pygame

# Dimensiones de la pantalla
ANCHO = 800
ALTO = 600
# Colores
BLANCO = (255, 255, 255)  # R,G,B en el rango [0,255], 0 ausencia de color, 255 toda la intensidad
VERDE_BANDERA = (27, 94, 32)    # un poco de rojo, más de verde, un poco de azul
ROJO = (255, 0, 0)      # solo rojo, nada de verde, nada de azul
AZUL = (0, 0, 255)      # nada de rojo, ni verde, solo azul


# Estructura básica de un programa que usa pygame para dibujar
def dibujarMenu(ventana, pantalla, botonJugar):
    ventana.blit(pantalla, (0,0))
    ventana.blit(botonJugar, (250, 425))


def dibujarJuego(ventana, pantallaJuego):
    ventana.blit(pantallaJuego, (0,0))


def dibujarMira(ventana, mira, pos):
    ventana.blit(mira, (pos[0]-24, pos[1]-24))


def dibujarPato(ventana, duck, duck1Pos, duck2Pos, duck3Pos):
    ventana.blit(duck, duck1Pos)
    ventana.blit(duck, duck2Pos)
    ventana.blit((pygame.transform.flip(duck,1,0)), duck3Pos)


def dibujarTiempo(ventana, tiempo, puntos, fuente, fuentePuntos):
    texto = fuente.render("Tiempo: " + str(tiempo), 1, (0,0,0))
    ventana.blit(texto, (500, 500))
    textoPuntos = fuentePuntos.render("Puntos: " + str(puntos), 1, (0,0,0))
    ventana.blit(textoPuntos, (50, 500))


def dibujarFinal(ventana, puntos, fuente, fuenteReiniciar, puntosGuardados, fuenteGuardados):

    texto = fuente.render("Has cazado a " +str(puntos) + " patos, ¡Buena caceria!", 1, (0,0,0))
    ventana.blit(texto, (125, 250))
    textoReiniciar = fuenteReiniciar.render("Reiniciar", 1, (0, 0, 0))
    ventana.blit(textoReiniciar, (150, 400))
    textoGuardados = fuenteGuardados.render("Tu puntuación maxima es de: " + str(puntosGuardados), 1, (0,0,0))
    ventana.blit(textoGuardados, (100, 50))


def dibujar():
    # Inicializa el motor de pygame
    pygame.init()
    # Crea una ventana de ANCHO x ALTO
    ventana = pygame.display.set_mode((ANCHO, ALTO))  # Crea la ventana donde dibujará
    reloj = pygame.time.Clock()  # Para limitar los fps
    termina = False  # Bandera para saber si termina la ejecución, iniciamos suponiendo que no

    pantalla = pygame.image.load("Pantalla_inicio.jpg")
    botonJugar = pygame.image.load("Start.png")
    pantallaJuego = pygame.image.load("pantallaJuego.png")
    mira = pygame.image.load("Mira.png")
    duck = pygame.image.load("duck.png")

    # Estados
    MENU = 1
    JUGANDO = 2
    FIN = 3
    estado = MENU

    duck1Pos = [-100, 0]
    duck2Pos = [-100, 200]
    duck3Pos = [800, 100]

    fuente = pygame.font.SysFont("Arial", 56)
    fuentePuntos = pygame.font.SysFont("Arial", 56)
    fuenteFinal = pygame.font.SysFont("Arial", 40)
    puntos = 0
    tiempo = 60
    ticks = 0

    pygame.mixer.init()
    pygame.mixer.music.load("Cancion.mp3")
    pygame.mixer.music.play(-1)


    while not termina:  # Ciclo principal, MIENTRAS la variable termina sea False, el ciclo se repite automáticamente
        # Procesa los eventos que recibe
        for evento in pygame.event.get():
            if evento.type == pygame.QUIT:  # El usuario hizo click en el botón de salir
                termina = True      # Queremos terminar el ciclo
            elif evento.type == pygame.MOUSEBUTTONDOWN:
                xMouse, yMouse = pygame.mouse.get_pos()
                if (xMouse > 250 and xMouse < 550) and (yMouse > 425 and yMouse < 725) and estado == MENU:
                    estado=JUGANDO
                if estado == JUGANDO:
                    if(xMouse >= duck1Pos[0] and xMouse <= duck1Pos[0]+100) and (yMouse >= duck1Pos[1] and yMouse <= duck1Pos[1]+100):
                        duck1Pos[0] = -100
                        puntos +=1
                    if (xMouse >= duck2Pos[0] and xMouse <= duck2Pos[0] + 100) and (yMouse >= duck2Pos[1] and yMouse <= duck2Pos[1] + 100):
                        duck2Pos[0] = -100
                        puntos += 1
                    if (xMouse >= duck3Pos[0] and xMouse <= duck3Pos[0] + 100) and (yMouse >= duck3Pos[1] and yMouse <= duck3Pos[1] + 100):
                        duck3Pos[0] = 800
                        puntos += 1
                if estado == FIN:
                    if (xMouse >= 150 and xMouse <= 400) and (yMouse >= 400 and yMouse <= 500):
                        estado = MENU
                        puntos = 0
                        tiempo = 60


        # Borrar pantalla
        ventana.fill(BLANCO)
        if estado==MENU:
            dibujarMenu(ventana, pantalla, botonJugar)
        elif estado==JUGANDO:
            dibujarJuego(ventana, pantallaJuego)
            pos = pygame.mouse.get_pos()
            dibujarMira(ventana, mira, pos)
            dibujarPato(ventana, duck, duck1Pos, duck2Pos, duck3Pos)
            dibujarTiempo(ventana, tiempo, puntos, fuente, fuentePuntos)
            duck1Pos[0] += 10
            duck2Pos[0] += 10
            duck3Pos[0] -= 10
            if(duck1Pos[0]>=900):
                duck1Pos[0] = -100
            if (duck2Pos[0] >= 900):
                duck2Pos[0] = -100
            if (duck3Pos[0] <= -100):
                duck3Pos[0] = 800
            ticks += 1
            if ticks >= 40:
                tiempo-=1
                ticks = 0
            if tiempo <= 0:
                estado = FIN

        elif estado == FIN:
            puntuaciones = open("puntuacion.txt", "r", encoding= "UTF-8")
            puntosGuardados = int(puntuaciones.readline())
            puntuaciones.close()
            if (puntos >= puntosGuardados):
                puntuaciones = open("puntuacion.txt", "w", encoding="UTF-8")
                puntuaciones.write(str(puntos))
                puntuaciones.close()
            dibujarFinal(ventana, puntos, fuenteFinal, fuente, puntosGuardados, fuentePuntos)




        pygame.display.flip()  # Actualiza trazos (Si no llamas a esta función, no se dibuja)
        reloj.tick(40)  # 40 fps

    # Después del ciclo principal
    pygame.quit()  # termina pygame


# Función principal, aquí resuelves el problema
def main():
    dibujar()   # Por ahora, solo dibuja


# Llamas a la función principal
main()