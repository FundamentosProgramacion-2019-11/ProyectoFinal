# Autor: Santiago España Vázquez
# Proyecto final: Juego en pygame - Poncho Man Zero 0 (2D sidescroller)

import pygame

# Dimensiones de la pantalla
ANCHO = 800
ALTO = 600
# Colores
BLANCO = (255, 255, 255)
ROJO = (255, 0, 0)
AZUL = (0, 0, 255)
MENUBACKGROUND = (49, 150, 96)
BACKGROUND = (75, 236, 255)


def putMenu(ventana, gameName, startButton):
    ventana.blit(gameName, (62, 50))
    ventana.blit(startButton, (266, 400))


def musicStates(state):
    if state == 1:
        pygame.mixer.init()
        pygame.mixer.music.load("menuMusic.mp3")
        pygame.mixer.music.play(-1)
    if state == 2:
        pygame.mixer.quit()
        pygame.mixer.init()
        pygame.mixer.music.load("inGameMusic.mp3")
        pygame.mixer.music.play(-1)



def drawGrass(ventana, grass, grassPos, secGrassPos):
    ventana.blit(grass, grassPos)
    ventana.blit(grass, secGrassPos)

def drawPonchoJump(ventana, jump, jumpspr, ponchoPos):
    ventana.blit(jump[jumpspr], ponchoPos)


def drawPonchoFall(ventana, jump, ponchoPos):
    ventana.blit(jump[2], ponchoPos)

def ponchoWalk(ventana, ponchoRun, movRight, ponchoPos, runspr, grassPos):
    if movRight == True and (ponchoPos[1]+126 >= grassPos[1]):
        ventana.blit(ponchoRun[runspr], ponchoPos)

def score(ventana, marcador, fuente):
    texto = fuente.render("Puntos: " + str(marcador), 1, (0,0,0))
    ventana.blit(texto, (ANCHO-300,10))


def drawLife(ventana, ponchoLifes, heart, brokenHeart):
    if ponchoLifes == 3:
        ventana.blit(heart, (25, 10))
        ventana.blit(heart, (75, 10))
        ventana.blit(heart, (125, 10))
    if(ponchoLifes == 2):
        ventana.blit(heart, (25, 10))
        ventana.blit(heart, (75, 10))
        ventana.blit(brokenHeart, (125, 10))
    if (ponchoLifes == 1):
        ventana.blit(heart, (25, 10))
        ventana.blit(brokenHeart, (75, 10))
        ventana.blit(brokenHeart, (125, 10))
    if (ponchoLifes == 0):
        ventana.blit(brokenHeart, (25, 10))
        ventana.blit(brokenHeart, (75, 10))
        ventana.blit(brokenHeart, (125, 10))


def drawSlimy(ventana, slimy, slimyPos, slimyspr):
    ventana.blit(pygame.transform.flip(slimy[slimyspr],1,0), slimyPos)


def drawDefeat(ventana, fuente, marcador, Lost):
    ventana.blit(Lost, (0, 0))
    texto = fuente.render(str(marcador), 1, (0, 0, 0))
    ventana.blit(texto, (480, 380))


def dibujar():
    pygame.init()
    ventana = pygame.display.set_mode((ANCHO, ALTO))
    reloj = pygame.time.Clock()
    termina = False

    gameName = pygame.image.load("GameName.png")
    startButton = pygame.image.load("StartButton.png")
    grass = pygame.image.load("FullGrass.png")
    heart = pygame.image.load("Heart.png")
    brokenHeart = pygame.image.load("EmptyHeart.png")

    #Animations
    #Poncho--------------------------------------------------------
    falling = True
    jumping = False

    jump = [pygame.image.load("Jump1.png"), pygame.image.load("Jump2.png"), pygame.image.load("Jump3.png")]
    jumpspr = 0
    jumpsprLim = 0

    ponchoRun = [pygame.image.load("PonchoR1.png"), pygame.image.load("PonchoR2.png"), pygame.image.load("PonchoR3.png"), pygame.image.load("PonchoR4.png")]
    runspr = 0
    runsprLim = 0

    slimy = [pygame.image.load("SlimyRun1.png"), pygame.image.load("SlimyRun2.png"), pygame.image.load("SlimyRun3.png"), pygame.image.load("SlimyRun4.png")]
    slimyspr = 0
    slimySprLim = 0

    Lost = pygame.image.load("Lost.png")


    MENU = 1
    PLAYING = 2
    LOST = 3
    state = MENU
    musicStates(state)

    fuente = pygame.font.SysFont("Arial", 56)
    time = 0
    marcador = 0
    marcadorLim = 0
    ponchoLifes = 3
    dmgDone = False

    R = 0
    G = 0
    B = 0

    lvlUpSpeed = 0
    levelVelocity = 7

    maxJumpHeight = 200

    ponchoPos = [200,0]

    slimyPos = [810,500]
    slimyPos2 = [910, 500]


    grassPos = [0, 545]
    secGrassPos = [800,545]
    while not termina:

        for evento in pygame.event.get():
            if evento.type == pygame.QUIT:
                termina = True
            elif evento.type == pygame.MOUSEBUTTONDOWN:
                xMouse, yMouse = pygame.mouse.get_pos()
                if (xMouse > 266 and xMouse < 534) and (yMouse > 400 and yMouse < 534) and state == MENU:
                    state=PLAYING
                    musicStates(state)

            elif evento.type == pygame.KEYDOWN:
                if evento.key == pygame.K_SPACE and jumping == False and falling == False:
                    jumping = True

        if(state == MENU):
            ventana.fill(MENUBACKGROUND)
            putMenu(ventana, gameName, startButton)
        elif(state == PLAYING):

            #FadeIn------------------------------------
            R += 3
            G += 3
            B += 3
            if R >= 75:
                R = 75
            if G >= 236:
                G = 236
            if B >= 255:
                B = 255
            ventana.fill((R, G, B))
            topVelocity = 25
            if(levelVelocity >= topVelocity):
                levelVelocity = topVelocity
            movRight = True
            #Grass
            drawGrass(ventana, grass, grassPos, secGrassPos)
            # MovingRight
            grassPos[0] -= levelVelocity
            secGrassPos[0] -= levelVelocity

            if grassPos[0] <= -800:
                grassPos[0] = secGrassPos[0]+800
            if secGrassPos[0] <= -800:
                secGrassPos[0] = grassPos[0]+800

            #Intensity
            if(lvlUpSpeed>= 30):
                levelVelocity += 3
                lvlUpSpeed = 0

            #Enemies
            drawSlimy(ventana, slimy, slimyPos, slimyspr)
            drawSlimy(ventana, slimy, slimyPos2, slimyspr)
            slimySprLim += 1
            if slimySprLim >= 4:
                slimyspr += 1
                slimySprLim = 0
            if slimyspr >= 4:
                slimyspr = 0
            slimyPos[0] -= levelVelocity
            slimyPos2[0] -= levelVelocity

            #DMG
            #1
            if ((ponchoPos[1]+126 >= slimyPos[1]) and falling == True) and ((ponchoPos[0]+56 >= slimyPos[0] and ponchoPos[0]+56 <= slimyPos[0]+64) or (ponchoPos[0] >= slimyPos[0] and ponchoPos[0] <= slimyPos[0]+64)):
                slimyPos[0] = 810
                marcador +=10
                lvlUpSpeed += 10
                maxJumpHeight=150
                jumping = True
                falling = False
            if((jumping == False and falling == False) and (slimyPos[0] <= ponchoPos[0]+73 and slimyPos[0]+64 >= ponchoPos[0]) and (ponchoPos[1]+126 >= slimyPos[1])):
                if( dmgDone == False and ponchoLifes == 3):
                    dmgDone = True
                    ponchoLifes = 2
                    slimyPos[0] = 810
                if (dmgDone == False and ponchoLifes == 2):
                    dmgDone = True
                    ponchoLifes = 1
                    slimyPos[0] = 810
                if (dmgDone == False and ponchoLifes == 1):
                    dmgDone = True
                    ponchoLifes = 0
                    slimyPos[0] = 810
            if (slimyPos[0] == 810):
                dmgDone = False
            if (slimyPos[0] <= 0):
                slimyPos[0] = 810
            #2
            if ((ponchoPos[1]+126 >= slimyPos2[1]) and falling == True) and ((ponchoPos[0]+56 >= slimyPos2[0] and ponchoPos[0]+56 <= slimyPos2[0]+64) or (ponchoPos[0] >= slimyPos2[0] and ponchoPos[0] <= slimyPos2[0]+64)):
                slimyPos2[0] = 910
                marcador +=10
                lvlUpSpeed += 10
                maxJumpHeight=150
                jumping = True
                falling = False
            if((jumping == False and falling == False) and (slimyPos2[0] <= ponchoPos[0]+73 and slimyPos2[0]+64 >= ponchoPos[0]) and (ponchoPos[1]+126 >= slimyPos2[1])):
                if( dmgDone == False and ponchoLifes == 3):
                    dmgDone = True
                    ponchoLifes = 2
                    slimyPos2[0] = 910
                if (dmgDone == False and ponchoLifes == 2):
                    dmgDone = True
                    ponchoLifes = 1
                    slimyPos2[0] = 910
                if (dmgDone == False and ponchoLifes == 1):
                    dmgDone = True
                    ponchoLifes = 0
                    slimyPos2[0] = 910
            if (slimyPos2[0] == 910):
                dmgDone = False
            if (slimyPos2[0] <= 0):
                slimyPos2[0] = 910
            #Gravity------------------------------------
            if(ponchoPos[1]+126 <= grassPos[1] and falling == True):
                ponchoPos[1] += 16
            if(ponchoPos[1]+126 >= grassPos[1]):
                jumpspr = 0
                falling = False
                maxJumpHeight = 200
            #-------------------------------------------
            if (movRight == True):
                ponchoWalk(ventana, ponchoRun, movRight, ponchoPos, runspr,  grassPos)
                runsprLim += 1
                if runsprLim >= 4:
                    runspr += 1
                    runsprLim = 0
                if runspr >= 4:
                    runspr = 0
            #Jump
            if(jumping == True):
                ponchoPos[1] -= 15
                if (ponchoPos[1] <= maxJumpHeight):
                    jumping = False
                    falling = True

            #JumpControl
            if(jumping == True):
                drawPonchoJump(ventana,jump, jumpspr, ponchoPos)
                jumpsprLim += 1
                if jumpsprLim == 6:
                    jumpspr +=1
                    jumpsprLim = 0
                if jumpspr >= 3:
                    jumpspr = 2
            if(jumping == False and falling == True):
                drawPonchoFall(ventana,jump, ponchoPos)
            score(ventana, marcador, fuente)
            marcadorLim += 1
            if marcadorLim >= 40:
                marcador += 1
                lvlUpSpeed += 1
                time += 1
                marcadorLim = 0
            drawLife(ventana, ponchoLifes, heart, brokenHeart)

            if ponchoLifes ==0:
                state = LOST

        elif state == LOST:
            ventana.fill(MENUBACKGROUND)
            drawDefeat(ventana, fuente,marcador,Lost)
            pygame.mixer.quit()


        pygame.display.flip()
        reloj.tick(40)

    pygame.quit()


def main():
    dibujar()


main()